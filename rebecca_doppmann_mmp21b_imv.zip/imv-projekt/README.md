# imv-projekt
 im v rebecca

 Idee des Projekts
 In meiner Bachelor-Arbeit befasse ich mich mit der Qualität im People-Journalismus. Als Lehrprojekt erstelle ich ein Konzept für ein audiovisuelles People-Format. Mit dieser Website habe ich eine Ergänzung dazu gebaut. Meine programmierte News-Seite soll als tägliche Sammlung von People-News dienen, wobei auch brandneue und aktuelle Themen behandelt werden. Mir war es auch wichtig, verschiedene Kategorien einzubauen. So können die Leser:innen auch nur ihre preferierten Inhalte konsumieren, indem sie sich auf die gewünschte Kategorie fokussieren.


 Schwierigkeiten
 Die grössten Probleme hatte ich mit der Suchfunktion. Alleine bis ich die Funtkion so weit hatte, wie sie jetzt ist, habe ich sehr lange gebraucht. Zuerst hat sich das  Such-Fenster nicht öffnen lassen, dann konnte ich nichts in die Suchleiste eingeben. Dann hat das CSS nicht so funktioniert, wie ich wollte und es wurde komisch oder teilweise gar nicht dargestellt. Mit ChatGPT konnte ich dann immer mehr Probleme lösen, bis es dann funktioniert hat. Allerdings habe ich es nicht geschafft, dass man ein Suchwort eingeben kann und die Suchfunktion dann die Inhalte durchsucht und sie ausgibt. Weder ChatGPT noch Tutorials konnten mir da helfen. Schliesslich habe ich es sein lassen, aber die halbe Funktion habe ich trotzdem stehen  lassen. Alleine dass sie sich öffnet und hübsch aussieht, darauf bin ich schon stolz. 
 Mein nächtes grosses Problem hatte ich beim Theme-Wechsel mit den Icons. Das Moon-Icon verschwindet nicht, auch wenn ich mich im Dark-Mode befinde. Während dem Programmieren hat es plötzlich funktioniert, dann nicht mehr. Schlussendlich habe ich das Problem nicht gefunden, weshalb es jetzt immernoch so ist. Aber dass sich das Theme wechseln  lässt, darauf bin ich sehr stolz.


 Learings
 Eines meiner grössten Learnings war die allgemeingültigen Definitionen im CSS. Als ich begonnen habe, mit den Farben und den Schriftarten der Website zu experimentieren, konnte ich das so sehr einfach machen. Somit konnte ich einfach die primäre Farbe anpassen und dann schauen, wie die Website so wirkt.
 Die Website repsonsive gestalten habe ich vorher als sehr mühsam empfunden. Als ich mich dann eingelesen hatte und das Konzept wirklich verstanden habe, gings dann etwas leichter. 


 Mögliche weitere Schritte
 In einem nächsten Schritt würde ich die Inhalte mit einem JSON-Element einfügen, anstatt für jede Seite ein HTML-File zu erstellen. Das habe ich nur so gemacht, um zu zeigen, wie die Website dann in etwa aussehen würde. Um die Vorlagen für die Seiten dann flexibel zu befüllen, müsste ich mit JSON arbeiten.
 Als nächstes hätte ich mich noch um die Bilder auf den Artikel-Seiten gekümmert. Teilweise sind die Bilder verzerrt oder es wir ein komischer Bilausschnitt angezeigt. Dass die Fotos schön dargestellt sind, wäre mir für einen nächsten Schritt noch wichtig.
 Was ich noch gerne gemacht hätte, ist die funktionierende Suchfunktion. Darüber habe ich aber bereits bei meinen Schwierigkeiten geschrieben.